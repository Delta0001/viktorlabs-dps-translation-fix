// Fantastic injection solution found at https://stackoverflow.com/a/9517879/1024788

var s = document.createElement('script');
s.src = chrome.runtime.getURL('script.js');
s.onload = function() {
    this.remove();
};
(document.head || document.documentElement).appendChild(s);