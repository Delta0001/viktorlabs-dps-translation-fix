# viktorlabs-dps-translation-fix
This extension overwrites victorlab's functions to print the ``appellation`` (English) value instead of ``name`` (Chinese).

Feel free to contribute to translate the rest of the page!
